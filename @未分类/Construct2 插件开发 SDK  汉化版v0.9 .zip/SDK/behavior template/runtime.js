﻿// 使用 ECMAScript 5 的严格模式
"use strict";

assert2(cr, "cr namespace not created");
assert2(cr.behaviors, "cr.behaviors not created");

/////////////////////////////////////
// Behavior class
// ***      这里改变行为的ID    *** - 必须匹配edittime.js的“id”属性
//           vvvvvvvvvv
cr.behaviors.MyBehavior = function(runtime)
{
	this.runtime = runtime;
};

(function ()
{
	// ***                        这里改变行为的ID *** - 必须匹配edittime.js的“id”属性
	//                               vvvvvvvvvv
	var behaviorProto = cr.behaviors.MyBehavior.prototype;
		
	/////////////////////////////////////
	// Behavior type class
	behaviorProto.Type = function(behavior, objtype)
	{
		this.behavior = behavior;
		this.objtype = objtype;
		this.runtime = behavior.runtime;
	};
	
	var behtypeProto = behaviorProto.Type.prototype;

	behtypeProto.onCreate = function()
	{
	};

	/////////////////////////////////////
	// Behavior instance class
	behaviorProto.Instance = function(type, inst)
	{
		this.type = type;
		this.behavior = type.behavior;
		this.inst = inst;				// 有关对象实例的修改
		this.runtime = type.runtime;
	};
	
	var behinstProto = behaviorProto.Instance.prototype;

	behinstProto.onCreate = function()
	{
		// 读取属性
		this.myProperty = this.properties[0];
		
		// 对象在这里被密封,所以确保设置好你需要的任何属性, e.g.
		// this.myValue = 0;
	};
	
	behinstProto.onDestroy = function ()
	{
		// 当对象被销毁时调用
		// 注意运行时可能让对象和行为 在这个调用之后回收 再利用;
		// 释放,回收或重置任何引用,这是飞船必要的
	};
	
	// 当储存完整的游戏状态时，调用
	behinstProto.saveToJSON = function ()
	{
		// return a Javascript object containing information about your behavior's state
		// note you MUST use double-quote syntax (e.g. "property": value) to prevent
		// Closure Compiler renaming and breaking the save format
		return {
			// e.g.
			//"myValue": this.myValue
		};
	};
	
	// 当读取完整的游戏状态时，调用
	behinstProto.loadFromJSON = function (o)
	{
		// 读取 通过 saveToJSON 储存的档案
		// 注意提供你相同的对象的属性'o' ,比如
		// this.myValue = o["myValue"];
		// 注意您必须使用双引号括号的 语法 来代替点 语法 (比如: o["property"])
		// 为了防止 经过编译器重命名后和或者改变保存格式 被破坏
	};

	behinstProto.tick = function ()
	{
		var dt = this.runtime.getDt(this.inst);
		
		// 每个tick都通过调用来更新 数据 ,注意this.inst 是必要的
		// 如果它是一个运动方式,dt值 就是从上一个tick为止 经过的时间
	};
	
	// 这些关于函数的注释保证 这些函数在导出时 它们会被移除, 
	// 插件发布后 调试器代码 不再生效。
	/**BEGIN-PREVIEWONLY**/
	behinstProto.getDebuggerValues = function (propsections)
	{
		// 附加你想在 debugger 里面出现的属性
		// 每个部分是一个对象有两个成员: "title/标题" 和 "properties/属性".
		// "properties/属性" 是在调试器中显示数据的数组
		// 这个数组包含名称和值,和其他一些可选的设置。
		propsections.push({
			"title": this.type.name,
			"properties": [
				// 每个属性条目可以使用以下值:
				// "name" (required): 属性名称 (在本段代码设置中这是必须的)
				// "value" (required): 一个布尔值、数字或字符串值
				// "html" (optional, default false): 设置为true来解析的名称和值
				//									 注意是作为HTML字符串,而不是简单的纯文本
				// "readonly" (optional, default false): 设置为true来禁用编辑属性
				
				// 例子:
				{"name": "My property", "value": this.myProperty}
			]
		});
	};
	
	behinstProto.onDebugValueEdited = function (header, name, value)
	{
		// 当非只读属性在debugger中修改时候调用
		// 通常你只需要 'name' (属性名) and 'value', 但是你也可以使用'header' 
		// (header的标题)可以区分具有相同名称的属性。
		if (name === "My property")
			this.myProperty = value;
	};
	/**END-PREVIEWONLY**/

	//////////////////////////////////////
	// Conditions
	function Cnds() {};

	// 条件 范例
	Cnds.prototype.IsMoving = function ()
	{
		// ...看看自带的行为是如何实现的 ...
		return false;
	};
	
	// ... 其他的条件写在这里 ...
	
	behaviorProto.cnds = new Cnds();

	//////////////////////////////////////
	// Actions
	function Acts() {};

	// 操作范例
	Acts.prototype.Stop = function ()
	{
		// ... 看看自带的行为是如何实现的 ...
	};
	
	// ... 其他的操作这在这里 ...
	
	behaviorProto.acts = new Acts();

	//////////////////////////////////////
	// Expressions
	function Exps() {};

	// 表达式范例
	Exps.prototype.MyExpression = function (ret)	// 'ret' 必须是第一个参数 - 总是通过它来返回表达式的结果
	{
		ret.set_int(1337);				// 返回值 (注意通过set_int()设置， 如果返回的类型不同，会报错)
		// ret.set_float(0.5);			// 返回浮点数
		// ret.set_string("Hello");		//返回字符串
		// ret.set_any("woo");			// 返回任意，字符串，数字等  
	};
	
	// ... 其他的表达式写在这里 ...
	
	behaviorProto.exps = new Exps();
	
}());