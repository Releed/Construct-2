﻿function GetBehaviorSettings()
{
	return {
		"name":			"MyBehavior",			// 出现在“添加行为”对话框中,可以改变,只要“id”保持不变
		"id":			"MyBehavior",			// 这是用来确定行为和保存项目;请永远不要改变它
		"version":		"1.0",					// ( x.y 格式的浮点数) 行为版本- C2显示兼容性警告 基于这个版本号
		"description":	"<出现在添加行为对话框的底部>",
		"author":		"<你的名字或组织>",
		"help url":		"<你的网站或人工输入Scirra.com>",
		"category":		"General",				// 你可以根据喜欢 写上现有的类别,但是你也可以设置任何东西
		"flags":		0						// 取消注释行,使标识flag生效……
					//	| bf_onlyone			// can only be added once to an object, e.g. solid
	};
};

////////////////////////////////////////
// Parameter types:
// AddNumberParam(label, description [, initial_string = "0"])			// 数字类型
// AddStringParam(label, description [, initial_string = "\"\""])		// 字符串类型
// AddAnyTypeParam(label, description [, initial_string = "0"])			// 接受一个数字或字符串
// AddCmpParam(label, description)										// 组合与等于，不等于，小于...
// AddComboParamOption(text)											// (放在 "AddComboParam"之前，添加组合项目)
// AddComboParam(label, description [, initial_selection = 0])			// 一个下拉列表参数
// AddObjectParam(label, description)									// 一个按钮点击并选择一个对象类型
// AddLayerParam(label, description)									// 接受一个层数或名称(字符串)
// AddLayoutParam(label, description)									// 一个下拉列表中所有项目布局
// AddKeybParam(label, description)										// 点击一个按钮,按下一个键(返回一个VK)
// AddAnimationParam(label, description)								// 一个字符串类型，输入时会自动联想存在动画名
// AddAudioFileParam(label, description)								//下拉列表出现所有导入项目的音频文件

////////////////////////////////////////
// Conditions

// AddCondition(id,					// 任何正整数来唯一地标识这个条件
//				flags,				// (参见文档中的内容) cf_none, cf_trigger, cf_fake_trigger, cf_static, cf_not_invertible,
//									// cf_deprecated, cf_incompatible_with_triggers, cf_looping
//				list_name,			// 出现在事件向导列表的名字
//				category,			// 出现在事件向导列表中的类别
//				display_str,		// 出现在事件表, - 使用 {0}, {1} 指代 parameters 并且 也可以用 <b></b>, <i></i> 强调粗体和斜体
//				description,		// 当选择条件时 会出现在事件向导对话框
//				script_name);		// 相应的运行时函数名
				
// example				
AddCondition(0, cf_none, "Is moving", "My category", "{my} is moving", "Description for my condition!", "IsMoving");

////////////////////////////////////////
// Actions

// AddAction(id,				// 任何正整数 (唯一地)用于标识该操作
//			 flags,				// (见参考文档) af_none, af_deprecated
//			 list_name,			// 出现在事件操作列表的名字
//			 category,			// 出现在事件操作列表的名字
//			 display_str,		// 出现在事件表的概述 - 使用 {0}, {1} 指代参数，也可以使用 <b></b>, <i></i>来强调
//			 description,		// 当选择出现在事件向导对话框 出现描述
//			 script_name);		// 相应的运行时函数名

// example
AddAction(0, af_none, "Stop", "My category", "Stop {my}", "Description for my action!", "Stop");

////////////////////////////////////////
// Expressions

// AddExpression(id,			// 任何正整数 (唯一地)用于标识该表达式
//				 flags,			//  (见参考文档) ef_none, ef_deprecated, ef_return_number, ef_return_string,
//								// ef_return_any, ef_variadic_parameters (必须指定一个返回值类型)
//				 list_name,		// 目前可以忽略, 但是如果在事件向导列表里出现请设置
//				 category,		// 出现在表达式面板中的分类
//				 exp_name,		// 在点语法后面的表达式名称, 比如 "foo"的 "myobject.foo" - 运行时函数名也一样
//				 description);	// 在表达式面板中的描述


// example
AddExpression(0, ef_return_number, "Leet expression", "My category", "MyExpression", "Return the number 1337.");

////////////////////////////////////////
ACESDone();

///////////////////////////////////////
// Array of property grid properties for this plugin
// new cr.Property(ept_integer,		name,	initial_value,	description)		// 一个整数
// new cr.Property(ept_float,		name,	initial_value,	description)		// 一个浮点数
// new cr.Property(ept_text,		name,	initial_value,	description)		// 一个字符串
// new cr.Property(ept_combo,		name,	"Item 1",		description, "Item 1|Item 2|Item 3")	// 下拉列表(initial_value  是最初选择项)
var property_list = [
	new cr.Property(ept_integer, 	"My property",		77,		"An example property.")
	];
	
// 当创建一个新的 行为 类 时 由IDE调用
function CreateIDEBehaviorType()
{
	return new IDEBehaviorType();
}

// Class 代表 IDE中的 行为 类
function IDEBehaviorType()
{
	assert2(this instanceof arguments.callee, "Constructor called as a function");
}

// 实例创建一个新的这种类型行为,由IDE时调用
IDEBehaviorType.prototype.CreateInstance = function(instance)
{
	return new IDEInstance(instance, this);
}

// Class 代表一个在IDE中的单个的实例的行为
function IDEInstance(instance, type)
{
	assert2(this instanceof arguments.callee, "Constructor called as a function");
	
	// 保存这个构造函数参数
	this.instance = instance;
	this.type = type;
	
	// 设置默认属性值的属性表
	this.properties = {};
	
	for (var i = 0; i < property_list.length; i++)
		this.properties[property_list[i].name] = property_list[i].initial_value;
		
	//这里设置其他的属性，比如, e.g...
	// this.myValue = 0;
}

// 在全部的实例的初始状态完成后， 通过IDE调用
IDEInstance.prototype.OnCreate = function()
{
}

// 当一个属性已经改变后,由IDE调用
IDEInstance.prototype.OnPropertyChanged = function(property_name)
{
}
