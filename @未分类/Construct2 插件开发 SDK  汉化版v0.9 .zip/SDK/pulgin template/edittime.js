﻿function GetPluginSettings()
{
	return {
		"name":			"MyPlugin",				// 出现在“插入对象”'insert object'对话框中,名字可以可以改变,只要id保持不变就行
		"id":			"MyPlugin",				// 插件需要靠id识别保存到项目的情况;所以永远不要改变它
		"version":		"1.0",					// (float in x.y format) 插件版本- C2显示兼容性警告基于此
		"description":	"<appears at the bottom of the insert object dialog>",
		"author":		"<your name/organisation>",
		"help url":		"<your website or a manual entry on Scirra.com>",
		"category":		"General",				// (分类用)如果你喜欢，可以用现有的类别,但是你可以设置其他的任何东西
		"type":			"world",				// 要么是 "world" (出现在布局中并且有绘图),要么是"object"
		"rotatable":	true,					// 当 "type" 是 "world"才能起效，  是否在对象里启用 旋转属性.
		"flags":		0						// .取消注释行,可以使标记生效……
					//	| pf_singleglobal		// 在项目范围的存在,如鼠标、键盘。类型必须是 object。
					//	| pf_texture			// 对象有一个单独贴图(例如，tiled background插件)
					//	| pf_position_aces		//  (添加以下条件)compare/set/get x, y... 
					//	| pf_size_aces			//  (添加以下条件)compare/set/get width, height...
					//	| pf_angle_aces			//  (添加以下条件)compare/set/get angle (建议把 "rotatable" 设置为 true)
					//	| pf_appearance_aces	//  (添加以下条件)compare/set/get visible, opacity...
					//	| pf_tiling				// 调整图像编辑器功能更好的适应平铺的图片(如tiled background 插件)
					//	| pf_animations			// 启用动画系统  就像'Sprite'插件一样 
					//	| pf_zorder_aces		// (添加Z轴控制)move to top, bottom, layer...
					//  | pf_nosize				// 防止在编辑器中调整大小
					//	| pf_effects			// 允许添加WebGL 的 特效添加
					//  | pf_predraw			// 为任何一个(非sprite)插件设置 预渲染 (例子: 
												// 对于一个对象有着单一的非图块图像，做些复杂的 draw时) - 如果影响正常工作，这是必需添加的标记
	};
};

////////////////////////////////////////
// Parameter types:
// AddNumberParam(label, description [, initial_string = "0"])			// 数字类型
// AddStringParam(label, description [, initial_string = "\"\""])		// 字符串类型
// AddAnyTypeParam(label, description [, initial_string = "0"])			// 接受一个数字或字符串
// AddCmpParam(label, description)										// 组合与等于，不等于，小于...
// AddComboParamOption(text)											// (放在 "AddComboParam"之前，添加组合项目)
// AddComboParam(label, description [, initial_selection = 0])			// 一个下拉列表参数
// AddObjectParam(label, description)									// 一个按钮点击并选择一个对象类型
// AddLayerParam(label, description)									// 接受一个层数或名称(字符串)
// AddLayoutParam(label, description)									// 一个下拉列表中所有项目布局
// AddKeybParam(label, description)										// 点击一个按钮,按下一个键(返回一个VK)
// AddAnimationParam(label, description)								// 一个字符串类型，输入时会自动联想存在动画名
// AddAudioFileParam(label, description)								//下拉列表出现所有导入项目的音频文件

////////////////////////////////////////
// Conditions

// AddCondition(id,					// 任何正整数来唯一地标识这个条件
//				flags,				// (参见文档)cf_none, cf_trigger, cf_fake_trigger, cf_static, cf_not_invertible,
//									// cf_deprecated, cf_incompatible_with_triggers, cf_looping
//				list_name,			// 出现在事件向导列表的名字
//				category,			// 出现在事件向导列表中的类别
//				display_str,		// 出现在事件表, - 使用 {0}, {1} 指代 parameters 并且 也可以用 <b></b>, <i></i> 强调粗体和斜体
//				description,		// 当选择条件时 会出现在事件向导对话框
//				script_name);		// 相应的运行时函数名
				
// example				
AddNumberParam("Number", "Enter a number to test if positive.");
AddCondition(0, cf_none, "Is number positive", "My category", "{0} is positive", "Description for my condition!", "MyCondition");

////////////////////////////////////////
// Actions

// AddAction(id,				// 任何正整数 (唯一地)用于标识该操作
//			 flags,				// (见参考文档) af_none, af_deprecated
//			 list_name,			// 出现在事件操作列表的名字
//			 category,			// 出现在事件操作列表的名字
//			 display_str,		// 出现在事件表的概述 - 使用 {0}, {1} 指代参数，也可以使用 <b></b>, <i></i>来强调
//			 description,		// 当选择出现在事件向导对话框 出现描述
//			 script_name);		// 相应的运行时函数名

// example
AddStringParam("Message", "Enter a string to alert.");
AddAction(0, af_none, "Alert", "My category", "Alert {0}", "Description for my action!", "MyAction");

////////////////////////////////////////
// Expressions

// AddExpression(id,			// 任何正整数 (唯一地)用于标识该表达式
//				 flags,			//  (见参考文档) ef_none, ef_deprecated, ef_return_number, ef_return_string,
//								// ef_return_any, ef_variadic_parameters (必须指定一个返回值类型)
//				 list_name,		// 目前可以忽略, 但是如果在事件向导列表里出现请设置
//				 category,		// 出现在表达式面板中的分类
//				 exp_name,		// 在点语法后面的表达式名称, 比如 "foo"的 "myobject.foo" - 运行时函数名也一样
//				 description);	// 在表达式面板中的描述

// example
AddExpression(0, ef_return_number, "Leet expression", "My category", "MyExpression", "Return the number 1337.");

////////////////////////////////////////
ACESDone();

////////////////////////////////////////
// Array of property grid properties for this plugin
// new cr.Property(ept_integer,		name,	initial_value,	description)		// 一个整数
// new cr.Property(ept_float,		name,	initial_value,	description)		// 一个浮点数
// new cr.Property(ept_text,		name,	initial_value,	description)		// 一个字符串
// new cr.Property(ept_color,		name,	initial_value,	description)		// 一个颜色下拉值
// new cr.Property(ept_font,		name,	"Arial,-16", 	description)		// 字体用给定的名称和大小
// new cr.Property(ept_combo,		name,	"Item 1",		description, "Item 1|Item 2|Item 3")	// 下拉列表(initial_value  是最初选择项)
// new cr.Property(ept_link,		name,	link_text,		description, "firstonly")		// 没有相关的值;简单地在点击之后调用调用“OnPropertyChanged”

var property_list = [
	new cr.Property(ept_integer, 	"My property",		77,		"An example property.")
	];
	
// 当创建一个新的对象类型时，由IDE调用
function CreateIDEObjectType()
{
	return new IDEObjectType();
}

//  在 IDE中 Class 代表一个对象的类型
function IDEObjectType()
{
	assert2(this instanceof arguments.callee, "Constructor called as a function");
}

// 当创建这种类型对象 的实例 时 通过IDE调用
IDEObjectType.prototype.CreateInstance = function(instance)
{
	return new IDEInstance(instance);
}

// 在IDE代表 单个实例的类
function IDEInstance(instance, type)
{
	assert2(this instanceof arguments.callee, "Constructor called as a function");
	
	// 保存这个构造函数参数
	this.instance = instance;
	this.type = type;
	
	// 设置默认属性值的属性表
	this.properties = {};
	
	for (var i = 0; i < property_list.length; i++)
		this.properties[property_list[i].name] = property_list[i].initial_value;
		
	// Plugin-specific variables
	// this.myValue = 0...
}

// 通过插入对话框第一次插入对象时调用
IDEInstance.prototype.OnInserted = function()
{
}

// 当双点击布局时调用
IDEInstance.prototype.OnDoubleClicked = function()
{
}

// 在属性栏中一个属性被改变之后调用
IDEInstance.prototype.OnPropertyChanged = function(property_name)
{
}

// 呈现对象加载字体或纹理
IDEInstance.prototype.OnRendererInit = function(renderer)
{
}

// 如果存在一个布局对象 则在编辑器中调用绘制
IDEInstance.prototype.Draw = function(renderer)
{
}

//释放字体渲染对象或纹理
IDEInstance.prototype.OnRendererReleased = function(renderer)
{
}