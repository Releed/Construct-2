﻿// 使用 ECMAScript 5 的严格模式
"use strict";

assert2(cr, "cr namespace not created");
assert2(cr.plugins_, "cr.plugins_ not created");

/////////////////////////////////////
// Plugin class
//    *** 在这里改变插件的ID *** - 必须匹配edittime.js的“id”属性
//          vvvvvvvv
cr.plugins_.MyPlugin = function(runtime)
{
	this.runtime = runtime;
};

(function ()
{
	/////////////////////////////////////
	//                      *** 在这里改变插件的ID *** - 必须匹配edittime.js的“id”属性
	//                            vvvvvvvv
	var pluginProto = cr.plugins_.MyPlugin.prototype;
		
	/////////////////////////////////////
	// 对象类型 类
	pluginProto.Type = function(plugin)
	{
		this.plugin = plugin;
		this.runtime = plugin.runtime;
	};

	var typeProto = pluginProto.Type.prototype;

	// 在启动时调用 每个对象类型
	typeProto.onCreate = function()
	{
	};

	/////////////////////////////////////
	// 实例 类
	pluginProto.Instance = function(type)
	{
		this.type = type;
		this.runtime = type.runtime;
		
		// 定义你需要的任何其他属性, e.g...
		// 比如 this.myValue = 0;
	};
	
	var instanceProto = pluginProto.Instance.prototype;

	// 每当创建一个实例调用
	instanceProto.onCreate = function()
	{
		// 注意这个调用后对象是密封的; 一定要设置好你需要的对象的任何属性
		// e.g...
		// this.myValue = 0;
	};
	
	// 当一个实例被销毁后调用
	// 注意运行时可能继续调用回收后的对象;确定好
	// 释放/回收/重置 等任何对其他对象的引用，都在这个函数处理
	instanceProto.onDestroy = function ()
	{
	};
	
	// called when saving the full state of the game 当储存完整的游戏状态时调用此函数
	instanceProto.saveToJSON = function ()
	{
		// 返回一个Javascript对象包含有关您的对象的状态信息
		// 注意您【必须】使用双引号语法(如: "property": value)来防止
		// 编译器关闭重命名 与 破坏了保存的格式 的情况
		return {
			// e.g.
			//"myValue": this.myValue
		};
	};
	
	// 当加载游戏的完整状态
	instanceProto.loadFromJSON = function (o)
	{
		// 通过读取之前saveToJSON 的数据 来加载状态
		// 比如你存储了'o'这个状态，加载后将还原它存储时的状态 , e.g.
		// this.myValue = o["myValue"];
		// 注意您【必须】使用双引号语法(如: "property": value)来防止
		// 编译器关闭重命名 与 破坏了保存的格式 的情况
	};
	
	// 如果一个布局对象- 使用canvas 2D 环境 (context)，则调用
	instanceProto.draw = function(ctx)
	{
	};
	
	// 如果一个布局对象- 使用WebGL 环境 (context)，则调用
	// "glw" 不是一个WebG的 con-text,这是一个包装器——你可以在GLWrap找到它的方法。
	// -js的安装的目录或复制其他插件来做什么功能。
	instanceProto.drawGL = function (glw)
	{
	};
	
	// 这些关于函数的注释保证 这些函数在导出时 它们会被移除, 
	// 插件发布后 调试器代码 不再生效。
	/**BEGIN-PREVIEWONLY**/
	instanceProto.getDebuggerValues = function (propsections)
	{
		// 附加你想在 debugger 里面出现的属性
		// 每个部分是一个对象有两个成员: "title/标题" 和 "properties/属性".
		// "properties/属性" 是在调试器中显示数据的数组
		// 这个数组包含名称和值,和其他一些可选的设置。
		propsections.push({
			"title": "My debugger section",
			"properties": [
				// 每个属性条目可以使用以下值:
				// "name" (required): 属性名称 (在本段代码设置中这是必须的)
				// "value" (required): 一个布尔值、数字或字符串值
				// "html" (optional, default false): 设置为true来解析的名称和值
				//									 注意是作为HTML字符串,而不是简单的纯文本
				// "readonly" (optional, default false): 设置为true来禁用编辑属性
				
				// 例子:
				// {"name": "My property", "value": this.myValue}
			]
		});
	};
	
	instanceProto.onDebugValueEdited = function (header, name, value)
	{
		// 当非只读属性在debugger中修改时候调用
		// 通常你只需要 'name' (属性名) and 'value', 但是你也可以使用'header' 
		// (header的标题)可以区分具有相同名称的属性。
		if (name === "My property")
			this.myProperty = value;
	};
	/**END-PREVIEWONLY**/

	//////////////////////////////////////
	// Conditions
	function Cnds() {};

	// 关于条件的例子
	Cnds.prototype.MyCondition = function (myparam)
	{
		// 如果数量是正整数的 返回true
		return myparam >= 0;
	};
	
	// ... 这里可以写其他的条件 ...
	
	pluginProto.cnds = new Cnds();
	
	//////////////////////////////////////
	// Actions
	function Acts() {};

	// 示范的添加action
	Acts.prototype.MyAction = function (myparam)
	{
		// alert 一个信息
		alert(myparam);
	};
	
	// ... 其他的action 请添加到这里 ...
	
	pluginProto.acts = new Acts();
	
	//////////////////////////////////////
	// 表达式
	function Exps() {};
	
	// 示范的表达式定义方法
	Exps.prototype.MyExpression = function (ret)	// 'ret' 必须是第一个参数 -总是通过它来返回表达式的结果
	{
		ret.set_int(1337);				// 返回一个值
		// ret.set_float(0.5);			// 返回一个浮点数
		// ret.set_string("Hello");		// ef_return_string
		// ret.set_any("woo");			// ef_return_any, 接受一个数字或字符串
	};
	
	// ... 其他的表达式写在这里 ...
	
	pluginProto.exps = new Exps();

}());